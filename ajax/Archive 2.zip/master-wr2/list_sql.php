<?php
	$list_sql = "SELECT npwrd,no_registrasi,nm_wp_wr,alamat_wp_wr,kecamatan,kelurahan,kota,tgl_pendaftaran FROM public.app_reg_wr WHERE(jenis_wr='2')";
?>